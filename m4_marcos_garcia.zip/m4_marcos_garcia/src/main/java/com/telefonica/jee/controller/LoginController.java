package com.telefonica.jee.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import javax.servlet.http.HttpSession;
import com.telefonica.jee.dao.UserDAO;
import com.telefonica.jee.dao.UserDAOImpl;
import com.telefonica.jee.entities.User;


/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RequestDispatcher dispatcher = null; 
	
	UserDAO userDAO = new UserDAOImpl();  //creamos objeto userDAO para poder llamar a los m�todos de la clase.
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// cogemos los par�metros email y password del formulario.
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		// Se comprueba que el usuario existe en la base de datos.
		if(userDAO.Login(email,password) == true) {
			

//			Usuario usario = userDao.findByEmail(email);
			
			HttpSession	session = request.getSession(true);
			//session.setAttribute("userLog",email);
			User userLog = userDAO.findByEmail(email);
			session.setAttribute("userLog",userLog);
		//	request.setAttribute("NOTIFICATION", "Bienvenido "+email);
//		   dispatcher = request.getRequestDispatcher("/views/UserList.jsp");
//			dispatcher = request.getRequestDispatcher("UserController");
			response.sendRedirect("UserController?action=LIST");
//			return;
//			dispatcher.forward(request, response);
			
		}else {
			request.setAttribute("NOTIFICATION", "El Usuario no existe en la base de datos");
			dispatcher = request.getRequestDispatcher("/views/Login.jsp");
			dispatcher.forward(request, response);
			
		}
//		doGet(request, response);
	}

}
