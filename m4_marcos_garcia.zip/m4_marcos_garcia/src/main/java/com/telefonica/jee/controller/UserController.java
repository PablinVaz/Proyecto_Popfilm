package com.telefonica.jee.controller;

import com.telefonica.jee.dao.UserDAO;
import com.telefonica.jee.dao.UserDAOImpl;
import com.telefonica.jee.entities.User;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/UserController")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	RequestDispatcher dispatcher = null;

	UserDAO userDAO = new UserDAOImpl(); // creamos objeto userDAO para poder llamar a los m�todos de la clase.

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String action = request.getParameter("action");

		if (action == null) {
			action = "LIST";
		}

		switch (action) {

		case "DELETE":
			deleteUser(request, response);
			break;
		case "EDIT":
			profile(request, response);
			break;
		case "LIST":
			listUsers(request, response);
		default:
			listUsers(request, response);
			break;
		}
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id");

		if (userDAO.delete(Integer.parseInt(id))) {
			request.setAttribute("NOTIFICATION", "Employee Deleted Successfully!");
		}

		listUsers(request, response);

	}

	private void listUsers(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession	session = request.getSession();
	    
	     User U =   (User) session.getAttribute("userLog");
	
		List<User> theList = userDAO.findAll();
		
		request.setAttribute("name", U.getName());
		request.setAttribute("id", U.getId());
		
		request.setAttribute("list", theList);

		dispatcher = request.getRequestDispatcher("/views/UserList.jsp");

		dispatcher.forward(request, response);
	}

	private void profile(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession	session = request.getSession();
	    
	     User U =   (User) session.getAttribute("userLog");
		
		request.setAttribute("name", U.getName());
		request.setAttribute("id", U.getId());
		String id = request.getParameter("id");

		User theUser = userDAO.get(Integer.parseInt(id));
		request.setAttribute("id", U.getId());

		request.setAttribute("user", theUser);

		dispatcher = request.getRequestDispatcher("/views/UserForm.jsp");

		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id");

		User user = new User();
		user.setName(request.getParameter("name"));
		user.setSurname(request.getParameter("surname"));
		user.setEmail(request.getParameter("email"));
		user.setPassword(request.getParameter("password"));
		user.setAge(Integer.parseInt(request.getParameter("age")));

		if (id.isEmpty() || id == null) {

			if (userDAO.create(user)) {
				request.setAttribute("NOTIFICATION", "Usuario creado correctamente!");
			}

		} else {
			
			user.setId(Integer.parseInt(id));
			if (userDAO.update(user)) {
				request.setAttribute("NOTIFICATION", "Usuario editado correctamente!");
			}
		}

		listUsers(request, response);
	}
}
