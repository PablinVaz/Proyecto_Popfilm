package com.telefonica.jee.dao;

import java.util.List;

import com.telefonica.jee.entities.User;

/**
 * Interfaz de User donde se declaran las operaciones CRUD y Login
 * 
 * @author Usuario
 *
 */

public interface UserDAO {

	/**
	 * findAll (no recibe parametros):
	 * 
	 * @return devuelve una lista de todos los usuarios de la base de datos
	 */
	public List<User> findAll();

	/**
	 * Recibe un objeto User y lo almacena en la base de datos,
	 * 
	 * @return devuelve true si se ha guardado correctamente y false si ha habido
	 *         alg�n error
	 */
	boolean create(User new_user);

	/**
	 * User get (entero id) recibe el id del usuario .
	 * 
	 * @return y devuelve el objeto usuario
	 */
	public User get(int id);

	/**
	 * delete (int id) Recibe un id y borra el User de la base de datos
	 * correspondiente a ese id.
	 */
	public boolean delete(int id);

	/**
	 * Login ( String email, String password)
	 * 
	 * @return si existe el usuario devuelve true si no existe devuelve false.
	 */
	public boolean Login(String email, String password);
	/**
	 * findUser (String email)
	 * Busca usuario en la base de datos con el mismo email.
	 * @return devuelve true si existe.
	 */

	/**
	 * Metodo para actualizar usuario
	 * @param update_user
	 * @return
	 */
    public boolean update (User update_user);
	
	/**
	 * M�todo que encuentra el usuario correspondiente a un email.
	 */
	public User findByEmail (String email);
}
