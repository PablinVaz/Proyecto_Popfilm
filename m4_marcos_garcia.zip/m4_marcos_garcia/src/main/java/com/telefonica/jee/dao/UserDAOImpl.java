package com.telefonica.jee.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;


import com.telefonica.jee.entities.User;
import com.telefonica.jee.util.JPAUtil;





public class UserDAOImpl implements UserDAO {
	// Query para comprobar usuario y contrase�a
	private static final String USER_COUNT = "SELECT COUNT(u) FROM User u WHERE u.email = :email AND u.password = :password"; 
	
	// creamos el objeto manager que permite acceder a las operaciones de
	// persistencia
//	private EntityManagerFactory managerFactory = Persistence.createEntityManagerFactory("m4_marcos_garcia"); 
	private EntityManager manager;
	
	
	//UserDAOImpl UserDAOImpl = new UserDAOImpl();
//	public UserDAOImpl() {
//		manager = managerFactory.createEntityManager();
//	}

	@Override
	public List<User> findAll() {

		    manager = JPAUtil.getEntityManager();
			// Realizamos una consulta en JPQL, que esta declarada en la clase User
			TypedQuery<User> query = manager.createNamedQuery("User.findAll", User.class);
			// Con getResultList se ejecuta la query y nos devuelve una lista de resultados
			List<User> UserList = query.getResultList();
			manager.close();
			return UserList;
			// si ha habido alg�n error lo capturamos.
		
	}

	@Override
	public boolean create(User new_user) {

		boolean flag = false; // Ponemos inicialmente el flag a false, por si hubiera cualquier problema
		try {
			manager = JPAUtil.getEntityManager();
			manager.getTransaction().begin(); // se abre la transmisi�n de datos
			manager.persist(new_user); // guardamos el usuario en la base de datos.
			manager.getTransaction().commit();// se cierra la tansmisis�n de datos.
			manager.close();
			flag = true; // se devuelve true cuando se ha guardado correctamente.
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return flag; // si se ha guardado correctamente se devuelve true, si no false.
	}

	@Override
	public User get (int id) {
		User user = null;
		try {
			manager = JPAUtil.getEntityManager();
			user = manager.find(User.class, id);
			manager.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public boolean delete(int id) {
		boolean flag = false;
		try {
			manager = JPAUtil.getEntityManager();
			manager.getTransaction().begin();   
			User deleteUser = manager.find(User.class, id);
			if (deleteUser != null) {
				manager.remove(deleteUser);
				manager.getTransaction().commit(); 
				flag = true;
			}
		manager.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public boolean Login(String email, String password) {
		manager = JPAUtil.getEntityManager();
		TypedQuery<Long> query = manager.createQuery(USER_COUNT, Long.class); // Arriba query completa
		query.setParameter("email", email); // Meter en la query el "email" con el email recibido por par�metro
		query.setParameter("password", password); // Meter en la query la "password" con la password recibida por par�metro
		Long numUsuario = query.getSingleResult(); // devuelve el resultado de la query.
		manager.close();
		if (numUsuario > 0) {
			return true;
		} // si el numero de usuarios es mayor que 0 es que existe en la base de datos
		return false;
	}
	


	@Override
	public boolean update(User update_user) {
		boolean flag = false;
		try {
			manager = JPAUtil.getEntityManager();
			manager.getTransaction().begin();   
			manager.merge(update_user); 
			manager.getTransaction().commit(); 
			manager.close();
			flag = true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
   public User findByEmail (String email)	{
	   
	   List<User> users = findAll();
	   User user = new User();
	    for (User user2 : users) {
	    	if(user2.getEmail().contentEquals(email)) {	
	    		user.setId(user2.getId());
	    		user.setEmail(user2.getEmail());
	    		user.setAge(user2.getAge());
	    		user.setName(user2.getName());
	    		user.setPassword(user2.getPassword());
	    		user.setSurname(user2.getSurname());
	    	}
	    }
	   return user;
   }
}
