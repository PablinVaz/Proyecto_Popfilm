package com.telefonica.jee.entities;

import java.io.Serializable;
import javax.persistence.*;
import javax.persistence.GeneratedValue;
/**
 * Implementaci�n de la entidad User:
 * 
 * int id -> id del usuario
 * String name -> nombre del usuario 
 * String surname -> Apellidos del usuario
 * String email -> email del usuario
 * String password -> password del usuario
 * int age -> edad en a�os del usuario
 * 
 */
@Entity
@Table(name = "user")
@NamedQuery(name = "User.findAll", query = "SELECT u FROM User u") // el From tiene que tener el mismo nombre que la clase

public class User implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private String surname;
	private String email;
	private String password;
	private int age;
	
	public User () {}

	public User(int id, String name, String surname, String email, String password, int age) {
		super();
		this.id = id;
		this.name = name;
		this.surname = surname;
		this.email = email;
		this.password = password;
		this.age = age;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", surname=" + surname + ", email=" + email + ", password="
				+ password + ", age=" + age + "]";
	}
	
	
	
	
}
