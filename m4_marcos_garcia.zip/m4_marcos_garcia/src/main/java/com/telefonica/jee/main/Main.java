package com.telefonica.jee.main;

import java.util.List;
import com.telefonica.jee.dao.UserDAOImpl;
import com.telefonica.jee.entities.User;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserDAOImpl userImpl = new UserDAOImpl();
//		// creamos un usuario.
    	User test = new User();
//		test.setAge(28);
        test.setEmail("admin@admin.com");
//		test.setPassword("admin");
//		test.setName("Admin");
//		test.setSurname("Admin");
//		if (userImpl.create(test)) {System.out.println("nuevo usuario creado");}
//		List<User> users = userImpl.findAll();
//		System.out.println(users);
		
		if (userImpl.Login("admin@admin.com","admin")){System.out.println("usuario encontrado!");
		}else {System.out.println("usuario no encontrado");}
		
		
	   	List<User> users =  userImpl.findAll();
		   User user = new User();
		    for (User user2 : users) {
		    	if(user2.getEmail().contentEquals(test.getEmail())) {		
		    		user.setEmail(user2.getEmail());
		    		user.setAge(user2.getAge());
		    		user.setName(user2.getName());
		    		user.setPassword(user2.getPassword());
		    		user.setSurname(user2.getSurname());
		    	}
		     }
		
		
		
		
		System.out.println(user);
	}

}
